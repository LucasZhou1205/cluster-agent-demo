import unittest
from decimal import Decimal

from group_order_agent import AgentConfig, GroupOrderAgent, Ledger, OrderInput, OrderItem


class GroupOrderAgentTest(unittest.TestCase):
    def setUp(self) -> None:
        self.ledger = Ledger()
        for uid in ["u1", "u2"]:
            self.ledger.credit_wallet(uid, Decimal("300"))
        self.agent = GroupOrderAgent(
            ledger=self.ledger,
            config=AgentConfig(
                group_window_minutes=10,
                delivery_fee=Decimal("8"),
                service_fee_rate=Decimal("0.03"),
                discount_threshold=Decimal("60"),
                discount_amount=Decimal("10"),
                max_single_order_amount=Decimal("400"),
            ),
        )

    def test_merge_and_checkout(self) -> None:
        o1 = self.agent.submit_order(
            OrderInput(
                user_id="u1",
                restaurant_id="r1",
                address_tag="office_a",
                items=[OrderItem(name="a", unit_price=Decimal("35"), quantity=1)],
                idempotency_key="k1",
            )
        )
        o2 = self.agent.submit_order(
            OrderInput(
                user_id="u2",
                restaurant_id="r1",
                address_tag="office_a",
                items=[OrderItem(name="b", unit_price=Decimal("30"), quantity=1)],
                idempotency_key="k2",
            )
        )
        self.assertEqual(o1.room_id, o2.room_id)
        settlement = self.agent.run_checkout(o1.room_id)
        self.assertEqual(settlement.total_discount, Decimal("10.00"))
        self.assertTrue(settlement.total_payable > Decimal("0"))
        self.assertEqual(self.agent.rooms[o1.room_id].status, "PAID")
        self.assertTrue(self.ledger.account_balance("merchant:r1") > Decimal("0"))
        self.assertTrue(self.ledger.account_balance("platform:revenue") > Decimal("0"))

    def test_idempotency(self) -> None:
        o1 = self.agent.submit_order(
            OrderInput(
                user_id="u1",
                restaurant_id="r2",
                address_tag="office_a",
                items=[OrderItem(name="x", unit_price=Decimal("20"), quantity=1)],
                idempotency_key="same-key",
            )
        )
        o2 = self.agent.submit_order(
            OrderInput(
                user_id="u1",
                restaurant_id="r2",
                address_tag="office_a",
                items=[OrderItem(name="x", unit_price=Decimal("20"), quantity=1)],
                idempotency_key="same-key",
            )
        )
        self.assertEqual(o1.order_id, o2.order_id)

    def test_risk_reject_large_order(self) -> None:
        with self.assertRaises(ValueError):
            self.agent.submit_order(
                OrderInput(
                    user_id="u1",
                    restaurant_id="r3",
                    address_tag="office_a",
                    items=[OrderItem(name="big", unit_price=Decimal("401"), quantity=1)],
                    idempotency_key="risk-key",
                )
            )


if __name__ == "__main__":
    unittest.main()
