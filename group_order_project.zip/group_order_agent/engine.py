from __future__ import annotations

from dataclasses import dataclass
from datetime import datetime, timedelta
from decimal import Decimal
from uuid import uuid4

from .models import GroupRoom, Order, OrderInput, RoomSettlement, money
from .payments import Ledger


@dataclass
class AgentConfig:
    group_window_minutes: int = 12
    delivery_fee: Decimal = money("8")
    service_fee_rate: Decimal = money("0.03")
    discount_threshold: Decimal = money("120")
    discount_amount: Decimal = money("18")
    max_single_order_amount: Decimal = money("500")


class GroupOrderAgent:
    def __init__(self, ledger: Ledger, config: AgentConfig | None = None) -> None:
        self.ledger = ledger
        self.config = config or AgentConfig()
        self.rooms: dict[str, GroupRoom] = {}
        self.orders: dict[str, Order] = {}
        self.idempotency_map: dict[str, str] = {}

    def submit_order(self, payload: OrderInput) -> Order:
        if payload.idempotency_key in self.idempotency_map:
            return self.orders[self.idempotency_map[payload.idempotency_key]]
        if payload.food_subtotal > self.config.max_single_order_amount:
            raise ValueError("触发风控：单笔订单金额超限")
        room = self._find_or_create_room(payload)
        order = Order(
            order_id=str(uuid4()),
            room_id=room.room_id,
            user_id=payload.user_id,
            restaurant_id=payload.restaurant_id,
            address_tag=payload.address_tag,
            items=payload.items,
            created_at=payload.created_at,
            food_subtotal=payload.food_subtotal,
        )
        room.order_ids.append(order.order_id)
        self.orders[order.order_id] = order
        self.idempotency_map[payload.idempotency_key] = order.order_id
        return order

    def settle_room(self, room_id: str) -> RoomSettlement:
        room = self.rooms[room_id]
        room.status = "LOCKED"
        room_orders = [self.orders[oid] for oid in room.order_ids]
        total_food = money(sum((o.food_subtotal for o in room_orders), start=money(0)))
        total_discount = self.config.discount_amount if total_food >= self.config.discount_threshold else money(0)
        total_delivery = self.config.delivery_fee
        users = {o.user_id for o in room_orders}
        user_food: dict[str, Decimal] = {u: money(0) for u in users}
        for o in room_orders:
            user_food[o.user_id] = money(user_food[o.user_id] + o.food_subtotal)

        user_payables: dict[str, Decimal] = {}
        user_merchant_receivables: dict[str, Decimal] = {}
        user_platform_fees: dict[str, Decimal] = {}
        for user_id, food_amount in user_food.items():
            ratio = Decimal("0") if total_food == 0 else (food_amount / total_food)
            user_discount = money(total_discount * ratio)
            discounted_food = money(food_amount - user_discount)
            user_delivery = money(total_delivery / len(users))
            user_service = money(discounted_food * self.config.service_fee_rate)
            payable = money(discounted_food + user_delivery + user_service)
            user_payables[user_id] = payable
            user_merchant_receivables[user_id] = discounted_food
            user_platform_fees[user_id] = money(payable - discounted_food)

        total_service_fee = money(sum((v * self.config.service_fee_rate for v in user_merchant_receivables.values()), start=money(0)))
        total_payable = money(sum(user_payables.values(), start=money(0)))
        return RoomSettlement(
            room_id=room_id,
            restaurant_id=room.restaurant_id,
            total_food=total_food,
            total_discount=total_discount,
            total_delivery=total_delivery,
            total_service_fee=total_service_fee,
            total_payable=total_payable,
            user_payables=user_payables,
            user_merchant_receivables=user_merchant_receivables,
            user_platform_fees=user_platform_fees,
        )

    def authorize_room(self, settlement: RoomSettlement) -> dict[str, str]:
        txs: dict[str, str] = {}
        for user_id, due in settlement.user_payables.items():
            txs[user_id] = self.ledger.hold(user_id, due)
        return txs

    def capture_room(self, settlement: RoomSettlement) -> dict[str, str]:
        room = self.rooms[settlement.room_id]
        users = list(settlement.user_payables.keys())
        txs: dict[str, str] = {}
        for user_id in users:
            merchant_amount = settlement.user_merchant_receivables[user_id]
            platform_amount = settlement.user_platform_fees[user_id]
            txs[user_id] = self.ledger.capture_from_hold(
                user_id=user_id,
                merchant_id=settlement.restaurant_id,
                merchant_amount=merchant_amount,
                platform_amount=platform_amount,
            )
        room.status = "PAID"
        return txs

    def run_checkout(self, room_id: str) -> RoomSettlement:
        settlement = self.settle_room(room_id)
        self.authorize_room(settlement)
        self.capture_room(settlement)
        return settlement

    def _find_or_create_room(self, payload: OrderInput) -> GroupRoom:
        for room in self.rooms.values():
            if (
                room.status == "OPEN"
                and room.restaurant_id == payload.restaurant_id
                and room.address_tag == payload.address_tag
                and room.close_at >= payload.created_at
            ):
                return room
        room_id = str(uuid4())
        room = GroupRoom(
            room_id=room_id,
            restaurant_id=payload.restaurant_id,
            address_tag=payload.address_tag,
            open_at=payload.created_at,
            close_at=payload.created_at + timedelta(minutes=self.config.group_window_minutes),
        )
        self.rooms[room_id] = room
        return room
